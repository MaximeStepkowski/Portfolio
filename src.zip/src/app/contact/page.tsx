export default function ContactPage() {
  return <p>Vous pouvez me contacter à mon adresse email...</p>;
}
